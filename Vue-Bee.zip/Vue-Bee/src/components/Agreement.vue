<template>
    <div class="bg-white">
        <div class="agree-header">
            mf178闲置资源转让协议
        </div>
        <div class="agree-con">
            <p class="text-center title"><span>mf178闲置资源转让协议</span></p>
            <p><span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; mf178闲置资源转让协议（以下称“本协议”）是深圳飞之度科技有限公司旗下的mf178平台（以下简称“甲方”或“mf178”或“本平台”）与mf178用户（以下简称“乙方”或“用户”或“您”）就闲置资源转让服务（或称”本服务”）所订立的有效合约。用户通过网络页面点击确认或以其他方式选择接受本协议，即表示用户与本平台已达成协议并同意接受本协议的全部约定内容。</span></p>
            <p>
                <span>&nbsp;</span>
            </p>
            <p><span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 在接受本协议之前，请用户仔细阅读本协议的全部内容（特别是以粗体下划线标注的内容）。如果您不同意本协议的任意内容，或者无法准确理解本平台对条款的解释，请不要进行后续操作。</span></p>
            <p>
                <span>&nbsp;</span>
            </p>
            <p><span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 第一条：相关定义</span></p>
            <p>
                <span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 闲置资源：</span>
                <span style="color:#8f8f94;">协议所称礼品卡，是指电子商务卡、商城超市卡、游戏充值卡、话费充值卡、旅游预付卡、石油预付充值卡等业务运营商发行的具有一定面值、可用于购买商品或服务的卡片。</span>
            </p>
            <p>
                <span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;闲置资源转让：本协议所称闲置资源转让，是指本平台提供的闲置资源转让服务。用户可将其持有的闲置资源，转让给本平台或本平台合作商户，转让所得的金额将直接转入用户mf178的账户余额中。具体支持的闲置资源以用户使用本服务时的页面提示为准。</span>
            </p>
            <p>
                <span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 第二条：费用</span>
            </p>
            <p>
                <span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 用户使用本服务需要支付一定的手续费，手续费已包含在闲置资源的寄售价中；</span>
            </p>
            <p>
            <span>如果用户选项加急服务，另需支付加急的费用，具体费用由mf178提交闲置资源的页面提示为准，加急服务费将直接从到账金额中扣除。</span>
            </p>
            <p>
                <span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 第三条：权利义务</span>
            </p>
            <p>
                <span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 使用本服务的用户，需符mf178用户实名制度。</span>
            </p>
            <p>
            <span>用户需按照页面提示选择正确的闲置资源面值。如选择的面值小于实际面值，本平台将按照选择的面值进行结算,当选择的面值大于实际面值，本平台将不结算。由此产生的损失由用户自行承担，本平台对此不承担责任；</span>
            </p>
            <p>
            <span>如因闲置资源过期或转让前已经使用等原因，导致闲置资源不能转让的，用户需自行解决，本平台不介入处理；</span>
            </p>
            <p>
                <span>本平台应按照本协议的约定及页面提示，向用户提供闲置资源转让服务，并保证用户成功转让的资金及时转入其mf178账户；</span>
            </p>
            <p>
                <span style="color: rgb(12, 12, 12);">            
                    <span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 鉴于互联网及网络交易的特殊性，本平台无法鉴别和判断虚拟交易或正在交易或已交易的闲置资源来源、权属、真伪、等权力属性、自然属性及其他各状况。因此，用户在交易前应加以仔细辨明，并慎重考虑和评估交易可能产生的各项风险。基于此，用户承诺，</span>
                    <span class="text-underline">用户在本平台所从事的闲置资源交易活动属于合法的，用户所提供的闲置资源均具有合法正当的来源；</span>
                    <span class="text-underline">经国家生效法律文书或行政处罚决定确认用户存在违法行为，或者本平台有足够事实依据可以认定用户存在违法或违反服务协议行为的，本平台有权选择下列一种或多种处理措施进行处理：</span>
                </span>
            </p>
            <p>
                <span class="text-underline">中止或终止用户网上交易权限；</span>
            </p>
            <p>
                <span class="text-underline">注销或删除用户帐户；</span>
            </p>
            <p>
                <span class="text-underline">在本平台公告上公布用户的违法行为；</span>
            </p>
            <p>
                <span class="text-underline">保留相应的交易记录提交公安机关处理。</span>
            </p>
            <p>
            <span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 第四条：风险承担及提示</span>
            </p>
            <p>
                <span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 在网上支付交易中，遇到网上交易不真实、欺诈、冒用、持卡人拒付或用户错误等风险造成损失，用户解决上述情况而导致的索赔等纠纷，本平台应予以协助。如因上述原因导致平台的损失，用户应当予以赔偿。</span>
            </p>
            <p>
                <span style="color: rgb(12, 12, 12);">            
                    <span>用户在使用本平台进行支付交易过程中，遵守中国人民银行网上银行业务和银行卡交易相关的政策法规，</span>
                    <span class="text-underline">不得进行虚假交易、洗钱、诈骗等非法行为</span>
                    <span>。</span>
                </span>
            </p>
            <p>
                <span>本平台发现或认为用户涉嫌违规、违法或犯罪活动的，本平台有权向用户发起调单，如因用户无法提供单据或提供的单据不符合要求的，用户应承担相应的法律责任。</span>
            </p>
            <p>
                <span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 第五条：其他</span>
            </p>
            <p>
            <span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 本协议适用中华人民共和国大陆地区法律。因本平台与用户就本协议的签订、履行或解释发生争议，双方应努力友好协商解决。如协商不成，本平台和用户同意由深圳飞之度科技有限公司所在地法院管辖审理双方的纠纷或争议；</span>
            </p>
            <p>
                <span style="color: rgb(12, 12, 12);">
                    <span>本协议内容包括协议正文及所有本平台已经发布的或将来可能发布的服务协议、隐私政策、交易规则等条款与本协议具有同等效力，您均应遵照执行；</span>
                    <span>本协议未尽事宜，以mf178网站上公布的《mf178闲置资源转让协议》等相关规则为准。</span>
                </span>
            </p>
            <p>
                <span style="">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 本平台所有权及本协议最终解释权归深圳飞之度科技有限公司所有。</span>
            </p>
            <br>
        </div>
        <div class="agree-foot">
            深圳飞之度科技有限公司
        </div>
    </div>
</template>
<script>
export default {
    
}
</script>
<style scoped >
.bg-white{
    background:#fff;
}
.agree-header{
    padding: 10px 15px;
    border-bottom:1px solid #c8c7cc;
    font-size:17px;
}
.agree-con{
     padding:10px 15px;
}
.agree-con .title{
    padding:10px;
}
.agree-con .title span{
    font-size:16px;
}
.agree-con p{
    margin-bottom:10px;
}
.agree-con p span{
    letter-spacing: 0px;
    font-size: 14px; 
    font-family: 微软雅黑; 
    color: rgb(12, 12, 12);
}
.agree-foot{
    padding:10px 15px;
    border-top:1px solid #c8c7cc;
    font-size:12px;
    color:#6d6d72;
}
.text-underline{
    text-decoration: underline;
}
</style>