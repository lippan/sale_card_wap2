<template>
    <div class="bg-white">
        <div class="agree-header">
            mf178卡密转让规则
        </div>
        <div class="agree-con">
            <p>1、注意：提交卡密面值时请仔细核对，如提交面值错误，会造成资金损失。</p>
            <p>例如：实际为500面值，提交平台为100面值，平台按照100面值结算。</p>
            <p>实际为100面值，提交平台为500面值，卡密会被使用且订单会失败处理，不予结算。</p>
            <p>2、注意：平台会报警。本平台是专业虚拟卡券回收平台，不接受洗钱，赃物等虚拟产品交易，如果发现有异常虚拟卡密（券），将保存相关证据，并提交给司法机关。</p><p>3、禁止在多个平台同时出售同一张卡密。</p><p>4、不丢弃实体卡。若有实体卡，提交成功后请勿丢弃。</p>
            <p>5、我已认真、反复阅读上述内容，一旦造成损失，我不会有任何借口。比如：我没认真看，我不是故意的等等。</p>
            <p><br></p>
        </div>
        <div class="agree-foot">
            深圳飞之度科技有限公司
        </div>
    </div>
</template>
<script>
export default {
    
}
</script>
<style scoped >
.bg-white{
    background:#fff;
}
.agree-header{
    padding: 10px 15px;
    border-bottom:1px solid #c8c7cc;
    font-size:17px;
}
.agree-con{
     padding:10px 15px;
}
.agree-con p{
    margin-top: 0;
    margin-bottom: 10px;
    color: #8f8f94;
}

.agree-foot{
    padding:10px 15px;
    border-top:1px solid #c8c7cc;
    font-size:12px;
    color:#6d6d72;
}

</style>